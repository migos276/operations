import os


DIR_NEW_TEMPLATE = 'new_templates'
NEW_PROJECT_DIR_NAME_PREFIX = 'designer_'
NEW_TEMPLATE_IMAGE_PATH = os.path.join(DIR_NEW_TEMPLATE, 'images')
DIR_PROFILES = 'profiles'
DESIGNER_CONFIG_FILE_NAME = 'config.ini'
