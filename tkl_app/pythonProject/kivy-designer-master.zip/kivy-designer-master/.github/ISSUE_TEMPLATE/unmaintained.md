---
name: UNMAINTAINED
about: Create a report to help us improve

---

**warning**

Please not that this project is currently unmaintained, as stated in the README, it's unlikely that bug report will trigger any quick fix. If you are interested in maintaining the project, please contact the kivy team using another mean (IRC, mail, kivy-dev user group…).

**Describe the bug**
A clear and concise description of what the bug is.
