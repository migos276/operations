# Change Log

## [2021.0314]

  - Add error correction property, refs #1
  - Enable cover testing, refs #3
  - CI build over Docker, refs #4
  - Fix border window coordinates, refs #15
  - Run tests under GitHub Actions, refs #18
  - Auto publish to PyPI, refs #19

## [2019.0914]

  - Migrate to new garden layout, refs #4
  - Setup continuous integration
  - Fix linting
  - Splits kvlang from code
  - Publish to PyPI

## [2019.0912]

  - Initial release before revamp, refs #4
