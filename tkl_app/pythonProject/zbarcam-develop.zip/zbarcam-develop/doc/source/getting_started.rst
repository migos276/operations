.. _started:

####################
  Getting Started
####################

.. toctree::
   :maxdepth: 2

   installation.md
   examples.md
