.. _zbarcam-api:

*******
Zbarcam
*******

:mod:`kivy_garden.zbarcam`
=============================

.. automodule:: kivy_garden.zbarcam
   :members:
   :undoc-members:
   :show-inheritance:
