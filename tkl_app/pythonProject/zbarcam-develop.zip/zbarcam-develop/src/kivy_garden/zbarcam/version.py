__version__ = '2020.0524'
# The `__version_code__` is used for the F-Droid auto update and should match
# the `versionCode` from the `build.gradle` file located in:
# `.buildozer/android/platform/build-*/dists/zbarcamdemo__*/build.gradle`
# The auto update method used is the `HTTP`, see:
# https://f-droid.org/en/docs/Build_Metadata_Reference/#UpdateCheckMode
__version_code__ = 721202524
